from flask import Flask, render_template, request
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
import PyPDF2
import os

torch.cuda.empty_cache()

app = Flask(__name__)

# Define the directory to save uploaded files
UPLOAD_FOLDER = os.path.join(app.instance_path, 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Load smaller pre-trained model and tokenizer
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = AutoModelForCausalLM.from_pretrained(
    "meta-llama/Llama-2-7b-chat-hf",
    device_map='auto',
    token = "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"
)

tokenizer = AutoTokenizer.from_pretrained("meta-llama/Llama-2-7b-chat-hf")

# Function to extract text from PDF
def extract_text_from_pdf(pdf_path):
    text = ""
    with open(pdf_path, 'rb') as file:
        pdf_reader = PyPDF2.PdfReader(file)
        for page in pdf_reader.pages:
            text += page.extract_text()
    return text  # Return the extracted text

# Function to generate response
def get_response(prompt, max_new_tokens=75):
    inputs = tokenizer(prompt, return_tensors="pt").to(device)
    outputs = model.generate(**inputs, max_new_tokens=max_new_tokens, temperature= 0.000001)
    response = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return response

# Homepage route
@app.route('/')
def home():
    return render_template('index.html')

# Route to handle form submission
@app.route('/generate', methods=['POST'])
def generate():
    pdf_file = request.files['pdf']
    prompt = request.form['prompt']
    
    # Save uploaded PDF file to the uploads folder
    pdf_path = os.path.join(UPLOAD_FOLDER, pdf_file.filename)
    pdf_file.save(pdf_path)
    
    # Generate response
    response = get_response(prompt)
    
    # Remove the uploaded PDF file after use
    os.remove(pdf_path)
    
    # Free GPU memory
    torch.cuda.empty_cache()
    
    return render_template('result.html', response=response)


if __name__ == '__main__':
    app.run(debug=True)
